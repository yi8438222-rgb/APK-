# 输入文件

推荐方式：把 A、B 两个 APK 放进一个 ZIP，然后命名为 `source_apks.zip`。ZIP 内必须直接包含：

- `base_ability.apk` — A，能力值版，实际包名 `jp.Recode21.pesane`
- `cn_source.apk` — B，CN 功能来源

这样 GitHub Actions 会自动解压并继续执行。

## 文件大小注意

GitHub 普通 Git 对单个文件执行 100 MiB 硬限制；浏览器网页上传则只有 25 MiB/文件。也就是说：如果 `source_apks.zip` 经过压缩后小于 100 MiB，可以用 Git 命令或 GitHub Desktop 提交；如果仍超过 100 MiB，就改用 Git LFS 或 Release/HTTPS 地址。

## 两种输入模式

### A+B ZIP（推荐）

`inputs/source_apks.zip`

ZIP 内直接放：`base_ability.apk`、`cn_source.apk`。

### 两个 APK 单独存放

也可以直接使用：

- `inputs/base_ability.apk`
- `inputs/cn_source.apk`

如果采用 Git LFS，使用：

```bash
git lfs install
git lfs track "inputs/*.apk"
git add .gitattributes inputs/*.apk
git commit -m "add APK inputs"
git push
```

### URL 模式

Actions 的 `Run workflow` 可以填写：

- `base_apk_url`
- `cn_apk_url`
- `apk_bundle_url`
- `translation_url`

其中 `apk_bundle_url` 指向包含 `base_ability.apk` 与 `cn_source.apk` 的 ZIP。

## ZIP 打包格式

不要把整个文件夹套在 ZIP 里。正确结构是：

```text
source_apks.zip
├── base_ability.apk
└── cn_source.apk
```

