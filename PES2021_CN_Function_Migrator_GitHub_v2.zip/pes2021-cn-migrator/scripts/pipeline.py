#!/usr/bin/env python3
import argparse, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

ANDROID_NS = 'http://schemas.android.com/apk/res/android'
A = f'{{{ANDROID_NS}}}'

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / 'config' / 'targets.json'


def run(cmd, cwd=None):
    print('[RUN]', ' '.join(map(str, cmd)))
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(p.stdout)
    if p.returncode:
        raise RuntimeError(f'command failed ({p.returncode}): {cmd}')
    return p.stdout


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()


def zip_names(apk):
    with zipfile.ZipFile(apk) as z: return z.namelist()


def apk_info(apk):
    names=zip_names(apk)
    dex=sorted(n for n in names if re.fullmatch(r'classes(?:\d+)?\.dex', n))
    so=sorted(n for n in names if '/lib/' in n and n.endswith('.so'))
    assets=sorted(n for n in names if n.startswith('assets/'))
    return {'size':os.path.getsize(apk),'sha256':sha256(apk),'dex':dex,'native':so,'assets':assets}


def decode(apk, outdir, apktool):
    if outdir.exists(): shutil.rmtree(outdir)
    outdir.parent.mkdir(parents=True, exist_ok=True)
    run(['java','-jar',str(apktool),'d','-f','-o',str(outdir),str(apk)])


def smali_files(decoded):
    return sorted(decoded.glob('smali*/**/*.smali'))


def descriptor_from_smali(path, root):
    rel=path.relative_to(root)
    parts=list(rel.parts)
    if parts[0]=='smali': parts=parts[1:]
    elif parts[0].startswith('smali_classes'): parts=parts[1:]
    else: return None
    if not parts or not parts[-1].endswith('.smali'): return None
    return 'L' + '/'.join(parts)[:-6] + ';'


def class_map(decoded):
    out={}
    for f in smali_files(decoded):
        d=descriptor_from_smali(f,decoded)
        if d: out[d]=f
    return out


def dotted(desc):
    return desc[1:-1].replace('/','.') if desc and desc.startswith('L') else desc


def is_feature(desc, cfg):
    d=dotted(desc)
    return any(d==x or d.startswith(x+'$') for x in cfg['feature_classes'])


def package_classes(decoded, prefixes):
    m=class_map(decoded)
    return {d:p for d,p in m.items() if any(dotted(d).startswith(x) for x in prefixes)}


def copy_class_file(src, base, work):
    rel=src.relative_to(work['cn'])
    # Preserve smali_classesN bucket from source, but remap collision-free classes to smali.
    dest=work['merged'] / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src,dest)
    return dest


def merge_feature_classes(base_dec, cn_dec, work, cfg, report):
    bm=class_map(base_dec); cm=class_map(cn_dec)
    copied=[]; conflicts=[]; missing=[]
    wanted={}
    for desc,p in cm.items():
        if is_feature(desc,cfg): wanted[desc]=p
    # Also copy all classes in the feature package roots, because synthetic/anonymous/inner
    # classes are dependencies of the listed public classes.
    roots=[
        'jp.konami.pesam.formation', 'jp.konami.pesam.graphics',
        'jp.konami.pesam.league', 'jp.konami.pesam.offline.ManualSkills',
        'jp.konami.pesam.offline.Skills3', 'jp.konami.pesam.service.Formation',
        'jp.konami.pesam.service.PlayerNames'
    ]
    for desc,p in cm.items():
        d=dotted(desc)
        if any(d.startswith(r) for r in roots): wanted[desc]=p

    # Keep only B classes that are not already in A. Same-name classes are never overwritten.
    existing=[int(x.name.replace('smali_classes','')) for x in work['merged'].glob('smali_classes*') if x.name.replace('smali_classes','').isdigit()]
    dex_index=max(existing+[1])+1
    feature_smali_dir=work['merged']/f'smali_classes{dex_index}'
    for desc,src in sorted(wanted.items()):
        if desc in bm:
            conflicts.append({'class':dotted(desc),'base':str(bm[desc]),'source':str(src),'action':'A_PRIORITY_MANUAL_MERGE_REQUIRED'})
            continue
        # Put class into a deterministic smali directory. apktool accepts multiple smali dirs.
        rel_parts=Path(*desc[1:-1].split('/')).with_suffix('.smali')
        # apktool recognizes smali, smali_classes2, smali_classes3, ...
        dest=feature_smali_dir / rel_parts
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dest)
        copied.append(dotted(desc))

    for req in cfg['feature_classes']:
        found=any(dotted(d)==req for d in cm)
        if not found: missing.append(req)
    report['feature_classes_requested']=cfg['feature_classes']
    report['feature_classes_copied']=copied
    report['feature_class_conflicts']=conflicts
    report['feature_class_missing']=missing
    return conflicts, missing


def migrate_native(base_dec, cn_dec, work, cfg, report):
    copied=[]; missing=[]
    for name in cfg['required_native']:
        matches=list(cn_dec.glob(f'lib/*/{name}'))
        if not matches:
            missing.append(name); continue
        for src in matches:
            rel=src.relative_to(cn_dec)
            dest=work['merged']/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dest); copied.append(str(rel))
    protected=[]
    for name in cfg['protected_native']:
        a=list(base_dec.glob(f'lib/*/{name}'))
        b=list(cn_dec.glob(f'lib/*/{name}'))
        protected.append({'name':name,'base_present':bool(a),'source_present':bool(b),'action':'BASE_PRESERVED'})
    report['native_copied']=copied; report['native_missing']=missing; report['protected_native']=protected
    return missing


def migrate_assets(base_dec, cn_dec, work, cfg, report):
    copied=[]; missing=[]
    for rels in cfg['required_assets']:
        src=cn_dec/rels
        if not src.exists(): missing.append(rels); continue
        dest=work['merged']/rels
        dest.parent.mkdir(parents=True,exist_ok=True)
        if (work['merged']/rels).exists() and sha256(src)!=sha256(work['merged']/rels):
            raise RuntimeError(f'asset collision: {rels}')
        shutil.copy2(src,dest); copied.append(rels)
    report['assets_copied']=copied; report['assets_missing']=missing
    return missing


def merge_manifest(base_dec, cn_dec, work, cfg, report):
    base=ET.parse(work['merged']/ 'AndroidManifest.xml')
    cn=ET.parse(cn_dec/'AndroidManifest.xml')
    br=base.getroot(); cr=cn.getroot()
    added=[]; conflicts=[]
    # Add only missing uses-permission declarations. Never change package name.
    existing_perm={x.get(A+'name') for x in br.findall('uses-permission')}
    for p in cr.findall('uses-permission'):
        n=p.get(A+'name')
        if n and n not in existing_perm:
            br.insert(0,p); existing_perm.add(n); added.append('permission:'+n)
    component_tags=('activity','activity-alias','service','receiver','provider')
    app=br.find('application')
    if app is None: raise RuntimeError('base manifest has no application element')
    existing_components={(x.tag,x.get(A+'name')) for tag in component_tags for x in app.findall(tag)}
    # Only migrate components whose class exists in the requested feature set / package namespace.
    cm=class_map(cn_dec)
    cset={dotted(d) for d in cm if is_feature(d,cfg)}
    for tag in component_tags:
        for c in cr.findall('.//'+tag):
            n=c.get(A+'name')
            if not n: continue
            full=n
            if n.startswith('.'):
                # Resolve against B package, not A package.
                pkg=cr.get('package','')
                full=pkg+n
            elif '.' not in n:
                full=cr.get('package','')+'.'+n
            if full not in cset: continue
            key=(tag,n)
            if key in existing_components: continue
            app.append(c); existing_components.add(key); added.append(f'{tag}:{n}')
    base.write(work['merged']/ 'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
    report['manifest_added']=added; report['manifest_conflicts']=conflicts


def translation_check(cn_dec, translation, report):
    data=json.loads(Path(translation).read_text(encoding='utf-8'))
    changes=data.get('changes',[])
    failures=[]; checked=0
    # Check that each English key appears somewhere in B decoded smali and that the mapped Chinese text appears too.
    texts=[]
    for f in smali_files(cn_dec):
        try: texts.append(f.read_text(encoding='utf-8',errors='ignore'))
        except Exception: pass
    blob='\n'.join(texts)
    for row in changes:
        if not isinstance(row,list) or len(row)<3: continue
        source,target=row[1],row[2]; checked+=1
        if source not in blob or target not in blob:
            failures.append({'source':source,'target':target,'found_source':source in blob,'found_target':target in blob})
    report['translation_expected_count']=data.get('changed_count',len(changes))
    report['translation_checked']=checked
    report['translation_failures']=failures
    return failures


def ability_check(base_dec, cfg, report):
    # We verify that the known ability targets are present in the base DEX smali. This is a structural guard,
    # not a re-derivation of values. The handoff document is the authority for the expected values.
    blob=''
    for f in smali_files(base_dec):
        try: blob += f.read_text(encoding='utf-8',errors='ignore')+'\n'
        except: pass
    found={str(k):(str(k) in blob) for k in cfg['ability_targets']}
    report['ability_targets']=cfg['ability_targets']; report['ability_id_presence']=found
    missing=[k for k,v in found.items() if not v]
    report['ability_target_presence_missing']=missing
    return missing


def detect_protected_changes(base_apk, merged_dir, report):
    # Ensure no OBB/CPK is introduced into the final decoded tree and protected native libraries are not sourced from B.
    bad=[]
    for p in merged_dir.rglob('*'):
        if p.is_file() and (p.suffix.lower() in {'.obb','.cpk'} or 'dt240' in p.name or 'dt241' in p.name): bad.append(str(p.relative_to(merged_dir)))
    report['forbidden_payloads']=bad
    return bad


def build(merged, out_apk, apktool, build_tools, keystore_path='', ks_alias='androiddebugkey', ks_pass='android', key_pass='android'):
    unsigned=out_apk.with_name(out_apk.stem+'_unsigned.apk')
    run(['java','-jar',str(apktool),'b',str(merged),'-o',str(unsigned)])
    zipalign=Path(build_tools)/'zipalign'; apksigner=Path(build_tools)/'apksigner'
    aligned=out_apk.with_name(out_apk.stem+'_aligned.apk')
    run([str(zipalign),'-f','4',str(unsigned),str(aligned)])
    temporary=False
    if keystore_path:
        keystore=Path(keystore_path)
    else:
        # Fallback only for CI smoke/install tests. It cannot replace an APK signed with the user's real key.
        keystore=out_apk.parent/'ci-debug.keystore'; temporary=True
        if not keystore.exists():
            run(['keytool','-genkeypair','-v','-keystore',str(keystore),'-storepass','android','-alias','androiddebugkey','-keypass','android','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Android Debug,O=Android,C=US'])
        ks_alias='androiddebugkey'; ks_pass='android'; key_pass='android'
    run([str(apksigner),'sign','--ks',str(keystore),'--ks-pass',f'pass:{ks_pass}','--key-pass',f'pass:{key_pass}','--ks-key-alias',ks_alias,'--out',str(out_apk),str(aligned)])
    run([str(apksigner),'verify','--verbose',str(out_apk)])
    for x in (unsigned,aligned):
        try: x.unlink()
        except: pass
    if temporary:
        try: keystore.unlink()
        except: pass


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--base',required=True); ap.add_argument('--cn',required=True); ap.add_argument('--translation',required=True)
    ap.add_argument('--out',required=True); ap.add_argument('--apktool',default=str(ROOT/'tools/apktool.jar'))
    ap.add_argument('--build-tools',default=''); ap.add_argument('--strict',default='true')
    ap.add_argument('--keystore',default=''); ap.add_argument('--ks-alias',default='androiddebugkey')
    ap.add_argument('--ks-pass',default='android'); ap.add_argument('--key-pass',default='android')
    args=ap.parse_args(); strict=str(args.strict).lower()=='true'
    base=Path(args.base); cn=Path(args.cn); trans=Path(args.translation); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    cfg=json.loads(CONFIG.read_text())
    workroot=out/'work'; analysis=out/'analysis'; analysis.mkdir(exist_ok=True)
    if workroot.exists(): shutil.rmtree(workroot)
    workroot.mkdir()
    work={'base':workroot/'base','cn':workroot/'cn','merged':workroot/'merged'}
    report={'status':'RUNNING','base':apk_info(base),'cn':apk_info(cn),'warnings':[],'errors':[]}
    print('[INFO] Base package is expected to be jp.Recode21.pesane')
    decode(base,work['base'],Path(args.apktool)); decode(cn,work['cn'],Path(args.apktool))
    shutil.copytree(work['base'],work['merged'])
    # package guard
    manifest=ET.parse(work['base']/'AndroidManifest.xml').getroot(); pkg=manifest.get('package')
    report['base_package']=pkg
    if pkg != cfg['base_package']:
        report['errors'].append(f'base package mismatch: {pkg} != {cfg["base_package"]}')
    # Basic analysis files
    (analysis/'base_classes.txt').write_text('\n'.join(sorted(dotted(d) for d in class_map(work['base']))),encoding='utf-8')
    (analysis/'cn_classes.txt').write_text('\n'.join(sorted(dotted(d) for d in class_map(work['cn']))),encoding='utf-8')
    conflicts,missing=merge_feature_classes(work['base'],work['cn'],work, cfg, report)
    if conflicts: report['errors'].append(f'{len(conflicts)} feature class name conflicts require method-level merge')
    if missing: report['warnings'].append(f'{len(missing)} requested feature classes not found in CN source')
    if migrate_native(work['base'],work['cn'],work,cfg,report): report['errors'].append('required native missing')
    if migrate_assets(work['base'],work['cn'],work,cfg,report): report['errors'].append('required asset missing')
    merge_manifest(work['base'],work['cn'],work,cfg,report)
    tf=translation_check(work['cn'],trans,report)
    if tf: report['errors'].append(f'{len(tf)} translation mappings did not verify in CN source')
    am=ability_check(work['base'],cfg,report)
    if am: report['errors'].append(f'{len(am)} ability IDs were not structurally found in base smali')
    if detect_protected_changes(base,work['merged'],report): report['errors'].append('forbidden OBB/CPK/dt240/dt241 payload detected')

    # Conflict report
    conflict_lines=['A/B class conflicts — A priority']
    conflict_lines += [c['class'] for c in conflicts]
    conflict_lines += ['', 'Requested feature classes missing from B'] + missing
    (out/'class_conflicts.txt').write_text('\n'.join(conflict_lines)+'\n',encoding='utf-8')
    report['status']='PASS' if not report['errors'] else 'FAIL'
    (out/'merge_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'verification_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if report['errors']:
        if strict:
            print('[FAIL] Strict mode: no APK will be produced.')
            return 2
        print('[WARN] Non-strict analysis mode: errors found, no APK will be produced.')
        return 0
    if not args.build_tools:
        print('[WARN] --build-tools not provided; analysis-only run.')
        return 0
    final=out/'PES2021_5.3.0_能力值版_CN功能_中文版.apk'
    build(work['merged'],final,Path(args.apktool),args.build_tools,args.keystore,args.ks_alias,args.ks_pass,args.key_pass)
    finalhash=sha256(final)
    (out/'final_apk_sha256.txt').write_text(finalhash+'  '+final.name+'\n',encoding='utf-8')
    print('[OK] Final APK:',final)
    return 0

if __name__=='__main__': sys.exit(main())
