#!/usr/bin/env python3
import argparse, json, zipfile, hashlib, re
from pathlib import Path

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def info(p):
 with zipfile.ZipFile(p) as z:
  n=z.namelist()
 return {'file':str(p),'size':p.stat().st_size,'sha256':sha(p),
 'dex':[x for x in n if re.fullmatch(r'classes(?:\d+)?\.dex',x)],
 'native':[x for x in n if x.startswith('lib/') and x.endswith('.so')],
 'assets':[x for x in n if x.startswith('assets/')],
 'has_obb':[x.endswith('.obb') for x in n]}

ap=argparse.ArgumentParser(); ap.add_argument('apk',nargs='+'); ap.add_argument('--out')
a=ap.parse_args(); data=[info(Path(x)) for x in a.apk]; print(json.dumps(data,ensure_ascii=False,indent=2))
if a.out: Path(a.out).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
