# PES2021 5.3.0 CN 功能迁移器：完整 GitHub Actions 教程

## 0. 你最终要得到什么

目标 APK：

- 以 A：`成功修改球员能力值版_clone.apk` 为唯一底座
- A 实际包名保持：`jp.Recode21.pesane`
- 保留 A 的能力值版本与核心 Offline 逻辑
- 从 B：`PES 2021 CN (110 OVR Custom Formation).apk` 迁移 CN 功能
- 加入 85 项中文化映射
- 不整体覆盖 A 的 DEX
- 不整体替换 A 的 `libUE4.so` / `libpesmasterbridge.so`
- 不修改 OBB、CPK、`dt240`、`dt241`

当前自动化项目采用“先分析、再严格合并、最后签名”的方式。出现未解决的同名类冲突时，严格模式停止，不生成可能运行异常的 APK。

## 1. 仓库目录

```text
pes2021-cn-migrator/
├── .github/
│   └── workflows/
│       ├── migrate.yml
│       └── lint.yml
├── config/
│   ├── targets.json
│   └── translation_map.json
├── docs/
│   ├── COMPLETE_TUTORIAL.md
│   ├── PROJECT_HANDOFF.md
│   ├── ARCHITECTURE.md
│   └── KNOWN_LIMITATIONS.md
├── inputs/
│   ├── README.md
│   └── source_apks.zip       # 推荐：A+B 放在这里
├── scripts/
│   ├── pipeline.py
│   └── inspect_apks.py
├── .gitattributes
├── .gitignore
├── README.md
└── requirements.txt
```

## 2. 先准备 A、B

把两个 APK 改成下面两个文件名：

```text
base_ability.apk
cn_source.apk
```

其中：

```text
base_ability.apk = A，能力值版，包名必须是 jp.Recode21.pesane
cn_source.apk    = B，CN 功能来源
```

## 3. 推荐做法：把两个 APK 放进一个 ZIP

ZIP 必须是下面这种结构，不能再多套一层文件夹：

```text
source_apks.zip
├── base_ability.apk
└── cn_source.apk
```

例如临时目录：

```text
C:\PES\bundle\
├── base_ability.apk
└── cn_source.apk
```

Windows PowerShell：

```powershell
Compress-Archive -Path .\base_ability.apk, .\cn_source.apk -DestinationPath .\source_apks.zip -Force
```

然后把：

```text
source_apks.zip
```

放到仓库：

```text
inputs/source_apks.zip
```

### 大小检查

GitHub 对普通 Git 单文件有 100 MiB 硬限制；建议你的 ZIP 不要卡在边界上，最好低于 95 MiB。

Windows PowerShell 检查字节数：

```powershell
(Get-Item .\source_apks.zip).Length
```

换算 MiB：

```powershell
(Get-Item .\source_apks.zip).Length / 1MB
```

注意：APK 本身就是 ZIP 容器，二次 ZIP 的压缩率通常不会特别高。所以原始 A+B 约 160 MB，并不保证一定能压到 100 MiB 以下。实际以生成后的 `source_apks.zip` 大小为准。

## 4. 一个非常重要的 GitHub 上传限制

GitHub 网页浏览器上传普通仓库文件时，每个文件上限是 25 MiB；通过 Git 命令行可以提交到 100 MiB，但超过 100 MiB 必须使用 Git LFS。citeturn459518search4turn338707search0

所以如果：

```text
source_apks.zip = 80 MiB
```

它符合普通 Git 的 100 MiB 限制，但是不能直接用网页的 Upload files 按钮上传，因为网页上传只有 25 MiB。应该使用 GitHub Desktop 或命令行提交。citeturn459518search4

如果 ZIP 大于 100 MiB，可以改用 Git LFS。GitHub Free 当前 Git LFS 单文件上限为 2 GB。citeturn338707search1

## 5. 创建 GitHub 仓库

在 GitHub 新建一个空仓库，例如：

```text
pes2021-cn-migrator
```

不要勾选自动生成 README、LICENSE、.gitignore，保持仓库尽量干净。

然后在本地进入项目根目录：

```bash
cd pes2021-cn-migrator
```

初始化并提交：

```bash
git init
git branch -M main
git add .
git commit -m "initial PES2021 CN migrator"
git remote add origin https://github.com/你的用户名/pes2021-cn-migrator.git
git push -u origin main
```

如果你已经有 GitHub 仓库，把 `origin` 地址替换成自己的地址。

## 6. 如果 ZIP 超过 100 MiB：Git LFS

安装 Git LFS 后执行：

```bash
git lfs install
git lfs track "inputs/source_apks.zip"
git add .gitattributes inputs/source_apks.zip
git commit -m "add A+B source bundle with Git LFS"
git push
```

仓库已经预留了 LFS 配置。Git LFS 在仓库里保存指针，实际大文件由 LFS 存储。citeturn338707search1

## 7. 不想把 APK 放进 Git：Release / HTTPS

这个项目也支持不把 APK 放在 Git 历史里。

GitHub Release 的单个 release asset 可以小于 2 GiB，因此更适合放大的二进制文件。citeturn459518search0

然后在 Actions 的 `Run workflow` 中填写：

```text
apk_bundle_url
```

让它下载一个包含：

```text
base_ability.apk
cn_source.apk
```

的 ZIP。

## 8. GitHub Actions 运行

进入：

```text
Actions
→ PES2021 CN Feature Migration
→ Run workflow
```

这个工作流使用 `workflow_dispatch` 手动触发，并带有输入参数。GitHub 官方支持这种网页手动运行方式。citeturn338707search9

### 推荐第一次运行参数

```text
strict = true
base_apk_url = 留空
cn_apk_url = 留空
apk_bundle_url = 留空
translation_url = 留空
```

因为默认会读取：

```text
inputs/source_apks.zip
config/translation_map.json
```

## 9. Actions 实际执行顺序

工作流会按下面顺序执行：

```text
Checkout
↓
读取 source_apks.zip
↓
解压出 base_ability.apk / cn_source.apk
↓
校验 SHA256 和 APK 结构
↓
Python 3.11
↓
Java 17
↓
Android SDK / Build Tools
↓
apktool 2.10.0
↓
A、B 分别反编译
↓
建立 class map
↓
以 A 为唯一底座
↓
迁移 B 的目标 CN 类
↓
迁移 3 个新增 native：
  libpesfps.so
  libpesformationsync.so
  libpesleague.so
↓
迁移 assets/my_league/player_names.json
↓
保留 A 的保护 native
↓
合并必要 Manifest 项
↓
检查 85 项中文化映射
↓
检查 15 个能力值 ID 是否仍存在
↓
检查是否出现 OBB/CPK/dt240/dt241
↓
严格模式检查
↓
apktool build
↓
zipalign
↓
apksigner 签名
↓
apksigner verify
↓
上传 APK + 报告 Artifact
```

## 10. 第一次失败也不要慌

第一次最值得看的不是 APK，而是 Actions 最后上传的报告：

```text
merge_report.json
verification_report.json
class_conflicts.txt
analysis/
```

### 如果出现：

```text
feature class name conflicts require method-level merge
```

说明 A 和 B 存在同名类，当前版本故意不覆盖 A，而是停止等待人工方法级合并。

这不是“程序坏了”，而是保护 A 的能力值和 Offline 核心逻辑，避免整个 DEX 被 B 替换。

## 11. 关键类优先级

以下类必须以 A 为准：

```text
jp.konami.pesam.offline.OfflineFirebaseProvider
jp.konami.pesam.offline.OfflineServer
jp.konami.pesam.offline.OfflineServer$LocalPlayerData
```

所以当前脚本不会直接用 B 覆盖它们。

## 12. 当前自动迁移的功能

目标类包括：

```text
FormationEditor
FormationNativeBridge
FormationStore
FormationData
FormationStudio
FormationWire
FrameSettings
FpsStartupRunnable
FpsNoOpRunnable
DuplicatePlanner
LeagueCore
LeagueRuntime
LeagueScreen
LeagueSession
LeagueTeamCatalog
ManualSkills
ManualSkillsUi
Skills3Logic
Skills3Names
PlayerNames
```

同时迁移：

```text
libpesfps.so
libpesformationsync.so
libpesleague.so
assets/my_league/player_names.json
```

## 13. 中文化

仓库里的：

```text
config/translation_map.json
```

包含 85 条映射。

当前脚本会先做结构性检查：源文本和目标中文是否在 B 的反编译 smali 中出现。

这一步不是最终的 UI 截图验收，因此即使通过，也仍建议安装 APK 后实际检查页面。

## 14. 能力值版本保护

仓库 `config/targets.json` 中固定保存 15 个目标 ID：

```text
137008 = 99
137009 = 99
137010 = 99
137012 = 99
144497 = 99
134860 = 99
143762 = 97
134570 = 98
142910 = 98
134450 = 98
150841 = 97
134851 = 98
150840 = 97
134454 = 96
138114 = 99
```

当前检查只负责确认这些 ID 仍存在于 A 的反编译 DEX 中；它不是重新推导数值的完整数据流验证。

## 15. 签名是最后一个关键点

如果最终 APK 要覆盖/更新你原来的 A，必须使用与原 APK 相同的签名密钥。

GitHub Secrets：

```text
ANDROID_KEYSTORE_B64
ANDROID_KEY_ALIAS
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_PASSWORD
```

其中：

`ANDROID_KEYSTORE_B64` = keystore 文件的 Base64 内容。

Windows PowerShell 示例：

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.keystore"))
```

把输出复制到 GitHub：

```text
Settings
→ Secrets and variables
→ Actions
→ New repository secret
```

### 如果暂时没有原来的签名密钥

当前工作流会自动创建临时 debug keystore，仅适合测试安装。

它不能保证能够覆盖原 A，因为 Android 会检查签名是否一致。

## 16. Actions 成功后去哪里拿 APK

打开对应的 workflow run，向下找到：

```text
Artifacts
```

下载：

```text
pes2021-cn-migration-数字.zip
```

里面会有：

```text
PES2021_5.3.0_能力值版_CN功能_中文版.apk
verification_report.json
merge_report.json
class_conflicts.txt
final_apk_sha256.txt
analysis/
```

Actions Artifact 用于保存 workflow 运行后生成的文件。citeturn338707search8

## 17. 本地测试命令

本地至少需要：

```text
JDK 17
Python 3.11+
Android SDK Build Tools
apktool 2.10.0
```

然后：

```bash
python scripts/pipeline.py \
  --base inputs/base_ability.apk \
  --cn inputs/cn_source.apk \
  --translation config/translation_map.json \
  --out out \
  --apktool tools/apktool.jar \
  --build-tools "$ANDROID_HOME/build-tools/35.0.0" \
  --strict true
```

## 18. 什么时候需要修改代码

只在 Actions 报告明确指出真实冲突时修改。

优先顺序：

```text
1. 看 class_conflicts.txt
2. 看 merge_report.json
3. 对具体同名类做方法级合并
4. 保留 A 的 Offline 核心与能力值逻辑
5. 再跑 strict=true
6. 通过后再签名输出
```

不要因为第一次失败，就直接把 B 的：

```text
classes.dex
classes2.dex
...
classes7.dex
```

整体替换到 A。

同样不要直接把 B 的：

```text
libUE4.so
libpesmasterbridge.so
```

覆盖 A。

## 19. 最重要的当前限制

当前仓库已经具备完整 GitHub Actions 工程结构，但此前在本地环境测试时，容器无法解析 GitHub 下载地址，因此没有在本地完成完整的 apktool → rebuild → sign 真实 APK 流程。

因此现在最可靠的验证方式是让 GitHub Actions 自己跑一次，利用它自己的网络环境下载 apktool 并执行真实构建。

第一次运行建议严格模式保持：

```text
strict = true
```

先拿到真实的 `class_conflicts.txt` / `merge_report.json`，再处理实际冲突，而不是凭猜测大改 DEX。
