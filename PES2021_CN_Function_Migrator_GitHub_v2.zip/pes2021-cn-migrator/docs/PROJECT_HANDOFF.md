# PES2021 Mobile 5.3.0 功能迁移项目交接文档
## GitHub Actions / 另一账号 GPT 专用技术说明

**核心目标：**

以“已经成功修改球员能力值版 APK”为最终底座，只把 CN 版本新增功能迁移进去，并保留 CN 半成品已经完成的中文化。

绝对不是把能力值版反向迁移到 CN APK。

---

## 1. 三个输入文件的角色

### A：最终基础 APK

文件：

`成功修改球员能力值版.apk`

这是整个项目的**唯一最终底座**。

最终 APK 必须从 A 开始构建。

A 已经有成功的球员能力值修改，因此：

- 不得换基础 APK
- 不得用 CN APK 作为基础重新打包
- 不得让 CN APK 覆盖 A 的核心离线逻辑
- 不得删除 A 的能力值代码

### B：CN 中文化功能源 APK

文件：

`PES2021_CNV中文版_迁移源_半成品_未签名.apk`

它不是最终 APK。

它只是**功能来源包**。

从 B 中迁移：

- FPS
- 120/90/60 FPS
- 跟随游戏
- FPS 显示
- Formation / 自定义阵容
- 阵型保存/读取/恢复
- 阵型方案
- League / 联赛
- Manual Skills / 手动技能
- Skills3
- PlayerNames
- 对应新增资源
- 对应原生库
- 已经中文化的新增 UI

### C：中文化映射表

文件：

`PES2021_CNV中文版_中文化映射表.json`

用途：

- 记录 B 已经处理过的中文字符串
- 用于验证迁移后 UI 是否仍为中文
- 不需要重新翻译原始 CN APK

---

## 2. 正确迁移方向

必须严格：

`A = 基础`

`B = 功能来源`

`C = 中文化参考`

正确：

A → 保留 A 全部内容 → 加入 B 新增功能 → 保留 B 中文化 → 最终 APK

错误：

B → 再加入 A 的能力值修改

绝对不要走错误方向。

---

## 3. A 中必须完整保留的能力值修改

### Messi 99

```text
137008 → 99
137009 → 99
137010 → 99
137012 → 99
144497 → 99
134860 → 99
```

### 新增球员

```text
143762 → 97
134570 → 98
142910 → 98
134450 → 98
150841 → 97
134851 → 98
150840 → 97
134454 → 96
138114 → 99
```

### 已确认能力修改路径

目标类：

```text
jp.konami.pesam.offline.OfflineServer$LocalPlayerData
```

目标构造：

```text
<init>(II[IIIIIIII)V
```

参数：

```text
p1 = uniqueId
p2 = rawId
p3 = parameters[]
p4 = position
p5 = overall
p6 = cardType
p7 = teamId0
p8 = teamId1
p9 = teamId2
p10 = nationId
```

`parameters` 长度：108。

核心修改：

```text
parameters[14..31] = 目标值
parameters[33..39] = 目标值
p5 / overall       = 目标值
```

必须保持原值：

```text
parameters[0..13]
parameters[32]
parameters[40..107]
```

特别注意：

`264281` 不是 Messi，不得加入 Messi 白名单。

---

## 4. A 中三个必须以 A 为准的核心类

```text
jp.konami.pesam.offline.OfflineFirebaseProvider
jp.konami.pesam.offline.OfflineServer
jp.konami.pesam.offline.OfflineServer$LocalPlayerData
```

尤其：

`OfflineFirebaseProvider`

此前迁移测试曾出现：

`ClassNotFoundException`

因此它是高优先级检查对象。

不能：

- 删除
- 重命名
- 用 B 整体覆盖
- 改 Java 包名
- 因 DEX 合并而丢失

---

## 5. Java 包命名空间

最终游戏 Java 命名空间继续：

```text
jp.konami.pesam.*
```

例如：

```text
jp.konami.pesam.offline.*
jp.konami.pesam.formation.*
jp.konami.pesam.graphics.*
jp.konami.pesam.league.*
jp.konami.pesam.service.*
```

不要做全局 `pesam → pesao`。

本项目不做共存改包。

最终目标包：

```text
jp.Recode21.pesam
```

---

## 6. FPS 功能

迁移：

```text
jp.konami.pesam.graphics.FrameSettings
jp.konami.pesam.graphics.FpsStartupRunnable
jp.konami.pesam.graphics.FpsNoOpRunnable
```

以及必要内部类和 Synthetic Lambda。

原生库：

```text
libpesfps.so
```

JNI：

```text
native install(int)
native renderCount()
native engineAverage()
```

对应：

```text
Java_jp_konami_pesam_graphics_FrameSettings_install
Java_jp_konami_pesam_graphics_FrameSettings_renderCount
Java_jp_konami_pesam_graphics_FrameSettings_engineAverage
```

功能：

```text
60帧
90帧
120帧
跟随游戏
FPS显示
当前FPS
平均FPS
```

---

## 7. FPS 中文化

B 已经完成中文化，不要重新翻译，也不要把英文资源覆盖回来。

至少保持：

```text
120帧
90帧
60帧
跟随游戏
帧率显示
平均帧率
当前帧率
帧率（重启游戏后生效）
在屏幕角落显示实时帧率
渲染 %.0f 帧/秒 · 目标 %d
设置已保存
保存帧率设置失败
帧率组件未启用，当前使用游戏原生帧率
帧率解锁未启用
```

实际文本以 B 和 C 为准。

---

## 8. Formation / 自定义阵容

迁移：

```text
jp.konami.pesam.formation.FormationEditor
jp.konami.pesam.formation.FormationNativeBridge
jp.konami.pesam.formation.FormationStore
```

以及：

```text
jp.konami.pesam.service.FormationData
jp.konami.pesam.service.FormationStudio
jp.konami.pesam.service.FormationWire
```

JNI：

```text
nativeSetBase(long base)
nativeQueue(int[] formation, boolean restore)
nativeStatus()
nativeIsSquadEditingScreen()
```

原生：

```text
libpesformationsync.so
```

主要能力：

- 打开阵型编辑
- 选择球员
- 拖动球员
- 修改位置
- 修改位置角色
- 保存
- 读取
- 恢复教练默认阵型
- 保存阵型方案
- 读取阵型方案
- 删除阵型方案
- 最多 30 个方案

需要保留 B 中 FormationStore / FormationStudio / FormationData / FormationWire 的实际实现，不重新发明逻辑。

---

## 9. Formation 中文化

最终新增 UI 应为中文，例如：

```text
编辑阵型
自定义阵型
拖动球员调整位置
保存
恢复
确定
取消
我的阵型方案
保存阵型方案
读取方案
删除阵型方案
恢复教练默认阵型
球员位置
位置角色
请先选择球员
请先选择非门将球员
门将位置保持固定
预览已恢复，请点击保存应用
阵型已保存，正在应用到当前阵容……
已恢复教练默认阵型
无法获取原始阵型
应用阵型失败
保存阵型失败
启动阵型编辑器失败
```

实际以 B/C 为准。

---

## 10. League / 联赛

迁移主要类：

```text
jp.konami.pesam.league.DuplicatePlanner
jp.konami.pesam.league.LeagueCore
jp.konami.pesam.league.LeagueRuntime
jp.konami.pesam.league.LeagueScreen
jp.konami.pesam.league.LeagueSession
jp.konami.pesam.league.LeagueTeamCatalog
```

以及必要内部类。

LeagueCore 主要接口包括：

```text
decode(byte[])
load(File)
abandon(long)
arm(long)
complete()
encode(long)
finish(long, int, int)
next()
opponent()
save(File)
table()
withTeamNames(Map)
```

LeagueRuntime JNI：

```text
nativeInstall()
nativeStart()
nativeSummary()
nativeEventCategory()
```

对应：

```text
Java_jp_konami_pesam_league_LeagueRuntime_nativeInstall
Java_jp_konami_pesam_league_LeagueRuntime_nativeStart
Java_jp_konami_pesam_league_LeagueRuntime_nativeSummary
Java_jp_konami_pesam_league_LeagueRuntime_nativeEventCategory
```

原生：

```text
libpesleague.so
```

保留：

- 联赛入口
- 创建赛季
- 赛程
- 对手
- 比赛结果
- 积分榜
- 保存
- 读取

---

## 11. League 中文化

至少保持：

```text
联赛
联赛模式
赛季
新赛季
赛程
积分榜
对手
下一场比赛
比赛结果
保存
读取
创建赛季
继续
完成
放弃
```

不要把 B 中已经完成的中文重新覆盖成英文。

---

## 12. Manual Skills / 技能

迁移：

```text
jp.konami.pesam.offline.ManualSkills
jp.konami.pesam.offline.ManualSkillsUi
jp.konami.pesam.offline.Skills3Logic
jp.konami.pesam.offline.Skills3Names
```

以及必要内部类。

功能：

- 技能列表
- 技能槽
- 选择技能
- 添加技能
- 训练
- 使用道具
- 确定
- 取消

主要方法包括：

```text
ManualSkills.addSkill(...)
ManualSkills.apply(...)
ManualSkills.cancel(...)
ManualSkills.find(...)
ManualSkills.indices()
ManualSkills.number(...)
ManualSkills.train(...)
ManualSkills.useItem(...)
ManualSkillsUi.show(...)
```

实际签名以 B 中 DEX 为准。

中文：

```text
手动技能
技能
技能槽
添加技能
训练
使用道具
确定
取消
关闭
选择技能
没有可用技能
选择无效
技能已添加
```

---

## 13. PlayerNames

迁移：

```text
jp.konami.pesam.service.PlayerNames
```

以及：

```text
assets/my_league/player_names.json
```

不能丢失。

---

## 14. DEX 合并原则

禁止整文件覆盖：

```text
B/classes.dex → A/classes.dex
B/classes2.dex → A/classes2.dex
```

正确做法：

```text
A 原有 DEX
+
B 新增类
+
必要的方法级修改
```

规则：

### A/B 类完全不同

B 新类直接加入。

### A/B 同名

A 优先。

只有当 B 的新增功能确实需要 A 中同名类的额外方法时，进行方法级合并。

特别是：

```text
OfflineFirebaseProvider
OfflineServer
OfflineServer$LocalPlayerData
```

必须以 A 为准。

---

## 15. Native 合并

必须加入：

```text
libpesfps.so
libpesformationsync.so
libpesleague.so
```

检查：

- ABI
- ELF
- JNI
- System.loadLibrary
- Java native declaration
- Native 符号/注册

不要只复制 `.so`。

---

## 16. libUE4.so 和 libpesmasterbridge.so

不要无条件使用 B 覆盖 A。

优先：

```text
A 原库
```

只有确认某个 CN 功能确实依赖 B 的 native 修改时，才做最小必要合并。

目标是：

不破坏：

- 游戏启动
- OfflineServer
- 能力值修改
- 原有离线逻辑

---

## 17. OBB / CPK

本次任务：

```text
不要修改 OBB
不要修改 CPK
不要修改 main.obb
不要修改 patch.obb
不要修改 dt240
不要修改 dt241
```

继续使用 A 原本兼容的 OBB。

除非之后单独授权，否则不要碰 OBB。

---

## 18. Manifest

最终 Manifest：

**以 A 为基础。**

只增加 CN 功能真正需要的组件。

必须保留：

```text
OfflineFirebaseProvider
```

不得删除 A 原来的 Provider / Activity / Service / Receiver。

---

## 19. 不需要迁移的无关模块

CN APK 里如果有：

- APK 工具辅助组件
- MT 管理器组件
- WakeUp Activity
- 与游戏功能无关的 Provider
- 其它无关 DEX

不要因为存在就整包复制。

只迁移本项目明确需要的：

```text
FPS
Formation
League
Manual Skills
PlayerNames
```

及其依赖。

---

## 20. GitHub Actions 推荐工作流

建议：

### Stage 1：输入检查

确认三个文件存在：

```text
base_ability.apk
cn_zh_source.apk
cn_translation_map.json
```

检查：

- ZIP 完整
- APK 可读取
- Manifest 可解析
- DEX 可读取

### Stage 2：分析 A

输出：

- package
- version
- DEX 数量
- ABI
- OfflineFirebaseProvider
- OfflineServer$LocalPlayerData
- 15 个能力值 ID

### Stage 3：分析 B

输出：

- DEX 数量
- Formation 类
- FPS 类
- League 类
- Manual Skills 类
- PlayerNames
- SO
- assets

不用重新研究原始 CN APK。

### Stage 4：类冲突扫描

输出：

```text
A only
B only
Both
```

核心冲突：

```text
OfflineFirebaseProvider
OfflineServer
OfflineServer$LocalPlayerData
```

遇到这些：

```text
A 优先
```

### Stage 5：功能类迁移

把 B 的：

```text
formation
graphics
league
service
ManualSkills
Skills3
```

必要类加入 A。

### Stage 6：资源迁移

加入：

```text
assets/my_league/player_names.json
```

以及真正属于这些功能的资源。

不要覆盖 A 原资源。

### Stage 7：Native

加入：

```text
libpesfps.so
libpesformationsync.so
libpesleague.so
```

对：

```text
libUE4.so
libpesmasterbridge.so
```

只比较，不自动无条件覆盖。

### Stage 8：Manifest

A 为基础，只新增必要项。

### Stage 9：构建

推荐标准流程：

```text
apktool / smali / d8
↓
构建
↓
zipalign
↓
apksigner
```

不要手工拼 APK Signing Block。

不要手工改 DEX 二进制布局。

---

## 21. 自动验收

最终必须检查：

### APK

- ZIP 完整
- Manifest 可解析
- APK 可安装解析

### 基础类

```text
OfflineFirebaseProvider
OfflineServer
OfflineServer$LocalPlayerData
```

### CN 功能类

```text
FormationEditor
FormationNativeBridge
FormationStore
FormationData
FormationStudio
FormationWire

FrameSettings
FpsStartupRunnable
FpsNoOpRunnable

LeagueCore
LeagueRuntime
LeagueScreen
LeagueSession
LeagueTeamCatalog
DuplicatePlanner

ManualSkills
ManualSkillsUi
Skills3Logic
Skills3Names

PlayerNames
```

### Native

```text
libpesfps.so
libpesformationsync.so
libpesleague.so
```

### 资源

```text
assets/my_league/player_names.json
```

---

## 22. 能力值验收

最终再次检查：

```text
137008 = 99
137009 = 99
137010 = 99
137012 = 99
144497 = 99
134860 = 99

143762 = 97
134570 = 98
142910 = 98
134450 = 98
150841 = 97
134851 = 98
150840 = 97
134454 = 96
138114 = 99
```

如果任意一个丢失：

```text
BUILD FAIL
```

---

## 23. 中文化验收

检查新增功能中的用户可见文本。

重点搜索：

```text
FPS
Formation
Editor
Save
Load
Reset
Apply
Cancel
Confirm
Close
Scheme
League
Season
Fixture
Table
Opponent
Manual
Skill
Train
Item
Position
```

如果这些英文出现在新增用户界面：

- 对照 B
- 对照 C
- 恢复中文

代码内部类名不翻译。

---

## 24. 最终禁止事项

绝对禁止：

- 用 B 作为最终 APK 底座
- 把 A 反向迁移到 B
- 用 B 整体覆盖 A 的 classes.dex
- 用 B 整体覆盖 A 的 classes2.dex
- 覆盖 OfflineFirebaseProvider
- 覆盖 OfflineServer
- 覆盖 OfflineServer$LocalPlayerData
- 删除 A 的能力值修改
- 修改 OBB
- 修改 CPK
- 修改 dt240
- 修改 dt241
- 整体覆盖 libUE4.so
- 整体覆盖 libpesmasterbridge.so
- 全局重命名 `jp.konami.pesam`
- 把 B 的英文 UI 覆盖回最终版本

---

## 25. 输出文件

最终：

```text
PES2021_5.3.0_能力值版_CN功能_中文版.apk
```

同时建议输出：

```text
final_apk_sha256.txt
verification_report.json
merge_report.json
class_conflicts.txt
```

GitHub Actions 日志建议输出：

```text
[OK] Base APK loaded
[OK] CN source APK loaded
[OK] Translation map loaded

[OK] OfflineFirebaseProvider preserved
[OK] OfflineServer preserved
[OK] OfflineServer$LocalPlayerData preserved

[OK] 15 ability targets preserved

[OK] Formation migrated
[OK] FPS migrated
[OK] League migrated
[OK] Manual Skills migrated
[OK] PlayerNames migrated

[OK] libpesfps.so
[OK] libpesformationsync.so
[OK] libpesleague.so

[OK] Chinese UI preserved

[OK] OBB unchanged
[OK] CPK unchanged

[OK] APK rebuilt
[OK] APK aligned
[OK] APK signed
```

未知项必须输出：

```text
[WARN]
```

不要伪造 `[OK]`。

---

# 26. 最终项目结构

```text
A：成功修改球员能力值版
          │
          │ 作为唯一底座
          ▼
   ┌───────────────┐
   │ 原游戏         │
   │ 原离线逻辑     │
   │ 15人能力值     │
   │ Provider       │
   │ OfflineServer  │
   └───────┬───────┘
           │
           │ 加入
           ▼
B：CN 中文化半成品
   ┌────────────────┐
   │ FPS             │
   │ Formation       │
   │ League          │
   │ Manual Skills   │
   │ PlayerNames     │
   │ Native SO       │
   │ 中文 UI         │
   └───────┬────────┘
           │
           ▼
       最终 APK
```

## 最重要的一句话

**以 A（成功修改能力值版）为唯一底座，只把 B（CN 中文化半成品）中的新增 FPS、Formation、League、Manual Skills、PlayerNames、必要资源和原生库迁移进去，同时保留 B 已完成的中文化。**

最终不是：

`CN APK + 我的能力值`

而是：

`我的能力值版 + CN 新功能 + CN 中文化`
