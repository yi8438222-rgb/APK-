# Source code index

本项目的完整可执行代码已经直接保存在仓库中：

- `.github/workflows/migrate.yml` — GitHub Actions 主工作流
- `.github/workflows/lint.yml` — Python/JSON 基础检查
- `scripts/pipeline.py` — A/B 解包、类筛选、native/assets/manifest 合并、验收、重打包、对齐、签名
- `scripts/inspect_apks.py` — APK 静态结构检查
- `config/targets.json` — 包名、15 个能力值目标、功能类、native、asset、保护 native
- `config/translation_map.json` — 85 项中文化映射
- `requirements.txt` — Python 依赖
