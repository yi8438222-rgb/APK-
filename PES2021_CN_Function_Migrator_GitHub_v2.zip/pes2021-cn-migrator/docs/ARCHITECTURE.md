# 架构与安全边界

## A/B/C

A 是 `jp.Recode21.pesane` 能力值版，唯一底座。
B 是 CN 功能来源。
C 是 85 项中文化映射表。

## 自动迁移

1. 解码 A/B。
2. 建立完整 class map。
3. 只把 Formation、Graphics/FPS、League、ManualSkills、Skills3、Formation service、PlayerNames 相关的 B 新类复制到 A。
4. A/B 同名类不覆盖，进入冲突报告。
5. 复制三个新增 `.so`。
6. 复制 `assets/my_league/player_names.json`。
7. Manifest 仅增加 B 中、且能对应到目标功能类的组件与缺失权限；不改变 A package。
8. 重新构建、zipalign、CI 临时签名。

## 暂不自动做

- `OfflineFirebaseProvider` / `OfflineServer` / `LocalPlayerData` 方法级合并。
- `libUE4.so` 与 `libpesmasterbridge.so` 二进制合并。
- OBB/CPK/dt240/dt241 修改。
- 直接复制 B 的 `res/`。原因是 Android resource ID 重新编译后可能与 B smali 中的硬编码 ID 不一致。

如果 B 功能依赖 A 中已经存在的同名类，则必须先完成方法级 diff/merge，再放开严格构建。

## 签名

GitHub Actions 优先读取 Secrets 中的正式签名密钥：`ANDROID_KEYSTORE_B64`、`ANDROID_KEY_ALIAS`、`ANDROID_KEYSTORE_PASSWORD`、`ANDROID_KEY_PASSWORD`。未配置时才使用临时 CI debug keystore；该 APK 仅用于测试，不能替换用户现有 A。若要覆盖/升级你现在的 A，必须提供与 A 原签名一致的 keystore。
