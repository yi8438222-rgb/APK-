# PES2021 5.3.0 CN 功能迁移器

以 `jp.Recode21.pesane` 的能力值版 APK 为唯一底座，把 CN 半成品中的 FPS、Formation、League、Manual Skills、PlayerNames、必要 Native/Assets 和中文化迁移到 A。

> **安全原则**：本项目不会用 CN APK 整体覆盖 A 的 DEX，也不会无条件覆盖 `libUE4.so` / `libpesmasterbridge.so`、OBB 或 CPK。A 的核心 Offline 类和 15 个能力值目标优先；无法安全自动合并的冲突会让构建失败或明确标记 WARN。

## 输入

推荐把 A+B 打成一个 ZIP：

- `inputs/source_apks.zip`
  - `base_ability.apk` — A，能力值版，共存包名 `jp.Recode21.pesane`
  - `cn_source.apk` — B，CN 功能来源
- `config/translation_map.json` — C，85 项中文化映射

也支持把两个 APK 分开保存，或在 Actions 中通过 HTTPS URL 提供。

也可以通过 GitHub Actions 的 **Run workflow** 上传 3 个文件。

## 输出

- `PES2021_5.3.0_能力值版_CN功能_中文版.apk`
- `verification_report.json`
- `merge_report.json`
- `class_conflicts.txt`
- `final_apk_sha256.txt`

## 本地运行

需要 JDK 17、Python 3.11+、Android SDK Build Tools、apktool 2.9+。

```bash
python3 scripts/pipeline.py \
  --base inputs/base_ability.apk \
  --cn inputs/cn_source.apk \
  --translation config/translation_map.json \
  --out out
```

## GitHub Actions

进入 **Actions → PES2021 CN Feature Migration → Run workflow**。默认会读取 `inputs/source_apks.zip`；也可以填写 `base_apk_url` / `cn_apk_url`，或者填写 `apk_bundle_url` 让 Actions 自动下载 A+B ZIP。GitHub 的 `workflow_dispatch` 支持在网页上手动运行并提供输入参数。

首次运行建议先把 `strict` 保持 `true`。只有所有关键检查通过才会生成正式 APK；如果出现需要人工方法级合并的冲突，流水线会停止，而不是生成一个表面成功但运行时可能崩溃的 APK。

## 项目边界

根据交接文档，本仓库当前不修改：

- `main.obb`
- `patch.obb`
- CPK
- `dt240`
- `dt241`
- A 的 `libUE4.so`
- A 的 `libpesmasterbridge.so`

最终包名固定沿用 A 实际包名 `jp.Recode21.pesane`，不会按交接文档中的旧示例 `jp.Recode21.pesam` 自动改名。
